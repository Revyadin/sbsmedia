import os
import glob
import subprocess
import shutil
from datetime import datetime, timedelta
import time


def create_timestamped_folder(src_folder):
    """Create a folder with a timestamp and copy contents of `src_folder` into it."""
    if not os.path.exists(src_folder):
        print(f"Source folder '{src_folder}' does not exist.")
        return None

    timestamp = datetime.now().strftime('%Y-%m-%d_%H.%M.%S')
    new_folder = f"_{timestamp}"

    try:
        if os.path.exists(new_folder):
            print(f"Destination folder '{new_folder}' already exists. Removing it...")
            shutil.rmtree(new_folder)

        shutil.copytree(src_folder, new_folder)
        print(f"Folder '{src_folder}' successfully copied to '{new_folder}'.")
        return new_folder
    except Exception as e:
        print(f"Error creating folder: {e}")
        return None


def get_duration(file_path):
    """Get the duration of a media file using ffprobe."""
    try:
        result = subprocess.run(
            ['ffprobe', '-v', 'error', '-show_entries', 'format=duration',
             '-of', 'default=noprint_wrappers=1:nokey=1', file_path],
            capture_output=True, text=True, check=True
        )
        return float(result.stdout.strip())
    except subprocess.CalledProcessError:
        print(f"Failed to get duration of {file_path}.")
        return None


def check_dependencies():
    """Check if FFmpeg is installed."""
    try:
        subprocess.run(['ffmpeg', '-version'], capture_output=True, check=True)
        print("FFmpeg is installed and ready to use.")
    except FileNotFoundError:
        print("FFmpeg not found. Please install it first.")
        return False
    return True


def create_video(new_folder, audio_file, cover, efek, output_file):
    """Create a video by combining audio, cover image, and overlay video."""
    # Combine paths
    audio_file = os.path.join(new_folder, audio_file)
    cover = os.path.join(new_folder, cover)
    efek = os.path.join(new_folder, efek)

    # Validate file existence
    if not os.path.exists(audio_file):
        print(f"Audio file '{audio_file}' not found.")
        return
    if not os.path.exists(cover):
        print(f"Cover image '{cover}' not found.")
        return
    if not os.path.exists(efek):
        print(f"Overlay video '{efek}' not found.")
        return

    # Get duration of the audio file
    duration_seconds = get_duration(audio_file)
    if duration_seconds is None:
        print("Invalid audio file duration.")
        return

    print(f"Audio duration: {timedelta(seconds=duration_seconds)}")

    # Build FFmpeg command
    ffmpeg_command = [
        'ffmpeg',
        '-y',
        '-stream_loop', '-1', '-i', efek,
        '-loop', '1', '-i', cover,
        '-i', audio_file,
        '-filter_complex',
        (
            "[1:v]scale=1920:1080[background];"
            "[0:v]colorkey=black:0.3:0.2,scale=1920:1080[overlay];"
            "[background][overlay]overlay=shortest=1:x=0:y=0[video]"
        ),
        '-map', '[video]',
        '-map', '2:a',
        '-c:v', 'libx264',
        '-preset', 'fast',
        '-t', str(duration_seconds),
        output_file
    ]

    # Execute FFmpeg and track progress
    process = subprocess.Popen(ffmpeg_command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    start_time = time.time()
    try:
        for line in process.stdout:
            if "time=" in line:
                elapsed_time = time.time() - start_time
                print(f"\rProcessing... Elapsed Time: {elapsed_time:.2f} seconds", end="")
    except KeyboardInterrupt:
        print("\nProcess interrupted by user.")
        process.terminate()

    process.wait()
    if process.returncode == 0:
        print(f"\nVideo successfully created: {output_file}")
    else:
        print(f"\nError during FFmpeg execution. Exit code: {process.returncode}")


def main():
    src_folder = "src"
    new_folder = create_timestamped_folder(src_folder)
    if not new_folder:
        return

    input(f"\nMake sure 'overlay.mp4', '*.mp3', and 'cover.jpeg' are inside {new_folder}.\n")

    # Check FFmpeg dependency
    if not check_dependencies():
        return

    # Get input files
    mp3_files = glob.glob(os.path.join(new_folder, "*.mp3"))
    if not mp3_files:
        print("No MP3 files found.")
        return

    audio_file = os.path.basename(mp3_files[0])  # Use the first MP3 file
    cover = "cover.jpeg"
    efek = "overlay.mp4"
    output_file = os.path.join(new_folder, "output.mp4")

    create_video(new_folder, audio_file, cover, efek, output_file)


if __name__ == "__main__":
    main()
